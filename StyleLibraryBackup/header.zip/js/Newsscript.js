	//Gallery Filters
	if($('.filter-list').length){
		$('.filter-list').mixItUp({});
	}

	


